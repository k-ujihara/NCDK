#!/bin/sh
make ISLINUX=1
